package  br.com.bytebank.banco.modelo;

public interface Tributavel {

     double GetValorImposto();


}
